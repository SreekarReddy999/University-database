--
-- PostgreSQL database dump
--

-- Dumped from database version 11.18 (Debian 11.18-0+deb10u1)
-- Dumped by pg_dump version 11.18 (Debian 11.18-0+deb10u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: u_course_enrollments; Type: TABLE; Schema: university; Owner: rg44k
--

CREATE TABLE university.u_course_enrollments (
    enrollment_id integer NOT NULL,
    student_id integer,
    course_id integer,
    semester character varying(255),
    year integer,
    grade character varying(2)
);


ALTER TABLE university.u_course_enrollments OWNER TO rg44k;

--
-- Name: u_courses; Type: TABLE; Schema: university; Owner: rg44k
--

CREATE TABLE university.u_courses (
    course_id integer NOT NULL,
    department_id integer,
    course_number character varying(255),
    course_name character varying(255),
    section_number integer,
    credit_hours integer,
    semester_id integer,
    year integer,
    professor character varying(255)
);


ALTER TABLE university.u_courses OWNER TO rg44k;

--
-- Name: u_departments; Type: TABLE; Schema: university; Owner: rg44k
--

CREATE TABLE university.u_departments (
    department_id integer NOT NULL,
    department_name character varying(255)
);


ALTER TABLE university.u_departments OWNER TO rg44k;

--
-- Name: u_grades; Type: TABLE; Schema: university; Owner: rg44k
--

CREATE TABLE university.u_grades (
    grade_id integer NOT NULL,
    student_id integer,
    course_id integer,
    grade integer
);


ALTER TABLE university.u_grades OWNER TO rg44k;

--
-- Name: u_semesters; Type: TABLE; Schema: university; Owner: rg44k
--

CREATE TABLE university.u_semesters (
    semester_id integer NOT NULL,
    semester_name character varying(255)
);


ALTER TABLE university.u_semesters OWNER TO rg44k;

--
-- Name: u_students; Type: TABLE; Schema: university; Owner: rg44k
--

CREATE TABLE university.u_students (
    student_id integer NOT NULL,
    student_name character varying(255),
    gpa double precision
);


ALTER TABLE university.u_students OWNER TO rg44k;

--
-- Data for Name: u_course_enrollments; Type: TABLE DATA; Schema: university; Owner: rg44k
--

COPY university.u_course_enrollments (enrollment_id, student_id, course_id, semester, year, grade) FROM stdin;
4	12361	1	Fall	2022	A
5	12356	2	Spring	2022	B
6	12357	3	Fall	2022	C
7	12361	4	Summer	2022	A
8	12358	5	Fall	2021	B
9	12359	6	Spring	2021	C
10	12360	7	Summer	2021	D
11	12356	8	Fall	2022	A
12	12357	9	Spring	2022	B
13	12358	1	Summer	2022	C
14	12359	2	Fall	2022	D
\.


--
-- Data for Name: u_courses; Type: TABLE DATA; Schema: university; Owner: rg44k
--

COPY university.u_courses (course_id, department_id, course_number, course_name, section_number, credit_hours, semester_id, year, professor) FROM stdin;
1	1	CSCI-101	Introduction to Computer Science	1	3	1	2022	John Doe
2	1	CSCI-102	Data Structures	1	3	2	2022	Jane
3	2	MATH-101	Calculus I	1	4	1	2022	John Smith
4	3	PHYS-101	Classical Mechanics	1	3	2	2022	J stvive
5	4	CHEM-101	General Chemistry	1	3	1	2022	Kim Jones
6	4	CHEM-102	Organic Chemistry	1	3	2	2022	Alice Smith
7	5	BIO-101	Introduction to Biology	1	3	1	2022	Jack Williams
8	6	HIST-101	World History	1	3	2	2022	Jane Doe
9	6	HIST-102	US History	1	3	1	2022	Bob Smith
\.


--
-- Data for Name: u_departments; Type: TABLE DATA; Schema: university; Owner: rg44k
--

COPY university.u_departments (department_id, department_name) FROM stdin;
1	Computer Science
2	Mathematics
3	Physics
4	Biology
5	Chemistry
6	Engineering
7	Economics
8	Psychology
9	Sociology
10	Political Science
11	History
12	Anthropology
13	Geography
14	Philosophy
15	Linguistics
\.


--
-- Data for Name: u_grades; Type: TABLE DATA; Schema: university; Owner: rg44k
--

COPY university.u_grades (grade_id, student_id, course_id, grade) FROM stdin;
1	12345	1	3
2	12345	2	4
3	12345	3	4
4	12345	4	4
5	12346	5	3
6	12347	6	4
7	12346	7	4
8	12348	8	4
9	12360	9	3
10	12361	1	4
11	12362	1	4
12	12359	1	4
13	12358	3	3
14	12357	4	4
15	12356	5	3
\.


--
-- Data for Name: u_semesters; Type: TABLE DATA; Schema: university; Owner: rg44k
--

COPY university.u_semesters (semester_id, semester_name) FROM stdin;
1	Fall
2	Spring
3	Summer
\.


--
-- Data for Name: u_students; Type: TABLE DATA; Schema: university; Owner: rg44k
--

COPY university.u_students (student_id, student_name, gpa) FROM stdin;
12345	Jane Doe	3.5
12346	John Doe	3.89999999999999991
12347	Bob Smith	2.5
12348	Sally Johnson	3.79999999999999982
12349	Jane Jones	3.20000000000000018
12350	John Davis	3.70000000000000018
12351	Bob Thompson	2.89999999999999991
12352	Sally Williams	3.60000000000000009
12353	Jane Brown	3.10000000000000009
12354	John Davis	3.5
12355	Bob Thompson	2.79999999999999982
12356	Sally Johnson	3.39999999999999991
12357	Jane Brown	3
12358	John Davis	3.29999999999999982
12359	Bob Thompson	2.70000000000000018
12360	Sally Johnson	3.20000000000000018
12361	Jane Brown	2.89999999999999991
12362	John Davis	3.10000000000000009
\.


--
-- Name: u_course_enrollments u_course_enrollments_pkey; Type: CONSTRAINT; Schema: university; Owner: rg44k
--

ALTER TABLE ONLY university.u_course_enrollments
    ADD CONSTRAINT u_course_enrollments_pkey PRIMARY KEY (enrollment_id);


--
-- Name: u_courses u_courses_pkey; Type: CONSTRAINT; Schema: university; Owner: rg44k
--

ALTER TABLE ONLY university.u_courses
    ADD CONSTRAINT u_courses_pkey PRIMARY KEY (course_id);


--
-- Name: u_departments u_departments_pkey; Type: CONSTRAINT; Schema: university; Owner: rg44k
--

ALTER TABLE ONLY university.u_departments
    ADD CONSTRAINT u_departments_pkey PRIMARY KEY (department_id);


--
-- Name: u_grades u_grades_pkey; Type: CONSTRAINT; Schema: university; Owner: rg44k
--

ALTER TABLE ONLY university.u_grades
    ADD CONSTRAINT u_grades_pkey PRIMARY KEY (grade_id);


--
-- Name: u_semesters u_semesters_pkey; Type: CONSTRAINT; Schema: university; Owner: rg44k
--

ALTER TABLE ONLY university.u_semesters
    ADD CONSTRAINT u_semesters_pkey PRIMARY KEY (semester_id);


--
-- Name: u_students u_students_pkey; Type: CONSTRAINT; Schema: university; Owner: rg44k
--

ALTER TABLE ONLY university.u_students
    ADD CONSTRAINT u_students_pkey PRIMARY KEY (student_id);


--
-- Name: u_course_enrollments u_course_enrollments_course_id_fkey; Type: FK CONSTRAINT; Schema: university; Owner: rg44k
--

ALTER TABLE ONLY university.u_course_enrollments
    ADD CONSTRAINT u_course_enrollments_course_id_fkey FOREIGN KEY (course_id) REFERENCES university.u_courses(course_id);


--
-- Name: u_course_enrollments u_course_enrollments_student_id_fkey; Type: FK CONSTRAINT; Schema: university; Owner: rg44k
--

ALTER TABLE ONLY university.u_course_enrollments
    ADD CONSTRAINT u_course_enrollments_student_id_fkey FOREIGN KEY (student_id) REFERENCES university.u_students(student_id);


--
-- Name: u_courses u_courses_department_id_fkey; Type: FK CONSTRAINT; Schema: university; Owner: rg44k
--

ALTER TABLE ONLY university.u_courses
    ADD CONSTRAINT u_courses_department_id_fkey FOREIGN KEY (department_id) REFERENCES university.u_departments(department_id);


--
-- Name: u_courses u_courses_semester_id_fkey; Type: FK CONSTRAINT; Schema: university; Owner: rg44k
--

ALTER TABLE ONLY university.u_courses
    ADD CONSTRAINT u_courses_semester_id_fkey FOREIGN KEY (semester_id) REFERENCES university.u_semesters(semester_id);


--
-- Name: u_grades u_grades_course_id_fkey; Type: FK CONSTRAINT; Schema: university; Owner: rg44k
--

ALTER TABLE ONLY university.u_grades
    ADD CONSTRAINT u_grades_course_id_fkey FOREIGN KEY (course_id) REFERENCES university.u_courses(course_id);


--
-- Name: u_grades u_grades_student_id_fkey; Type: FK CONSTRAINT; Schema: university; Owner: rg44k
--

ALTER TABLE ONLY university.u_grades
    ADD CONSTRAINT u_grades_student_id_fkey FOREIGN KEY (student_id) REFERENCES university.u_students(student_id);


--
-- PostgreSQL database dump complete
--

